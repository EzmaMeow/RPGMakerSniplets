NOTE: This project is a 'fake' game for April first. It is more or less a rough demo of a few systems I work on 
as well as a challange to release something similar to a game. 

This version need the Rpg Maker VX Ace RTP to play.
